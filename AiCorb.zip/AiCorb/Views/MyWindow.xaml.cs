﻿using System.Windows;
using System.Windows.Controls;

namespace AiCorb.Views
{
    public partial class MyWindow : Window
    {
        public MyWindow()
        {
            InitializeComponent();
        }
    }
}