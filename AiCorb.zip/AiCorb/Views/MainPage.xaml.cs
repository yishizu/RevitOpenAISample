﻿using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace AiCorb.Views
{
    public partial class MainPage : Window
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}